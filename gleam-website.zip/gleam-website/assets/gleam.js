/* Gleam: cookie choices banner.
   Drives Wix's consent policy (loaded by the Wix site script), so Wix Analytics and any
   Google Analytics / Tag Manager connected in the Wix dashboard follow the visitor's choice. */
(function () {
  var KEY = 'gleam-consent';
  var VERSION = 1;

  function read() {
    try {
      var v = JSON.parse(localStorage.getItem(KEY) || 'null');
      return v && v.version === VERSION ? v : null;
    } catch (e) { return null; }
  }
  function write(choice) {
    try { localStorage.setItem(KEY, JSON.stringify({ choice: choice, version: VERSION, at: new Date().toISOString() })); } catch (e) {}
  }
  function applyToWix(choice) {
    var on = choice === 'all';
    var policy = { functional: on, analytics: on, advertising: on, dataToThirdParty: on };
    function go() {
      try { window.consentPolicyManager.setConsentPolicy(policy); } catch (e) {}
    }
    if (window.consentPolicyManager) go();
    else window.addEventListener('consentPolicyManagerReady', go, { once: true });
  }

  var css =
    '.gc{position:fixed;z-index:96;left:max(16px,env(safe-area-inset-left,0px));right:max(16px,env(safe-area-inset-right,0px));bottom:max(16px,env(safe-area-inset-bottom,0px));max-width:30rem;padding:20px;border:1px solid rgba(243,241,234,0.22);border-radius:10px;background:#111114;color:#f3f1ea;font-family:"Onest",system-ui,-apple-system,"Segoe UI",sans-serif;font-size:15px;line-height:1.5;box-shadow:0 18px 50px rgba(0,0,0,0.55);transform:translateY(calc(100% + 32px));opacity:0;transition:transform 420ms cubic-bezier(0.16,1,0.3,1),opacity 300ms ease-out}' +
    '.gc.on{transform:none;opacity:1}' +
    '.gc h2{font-size:13px;font-weight:600;text-transform:uppercase;letter-spacing:0.18em;margin:0 0 8px}' +
    '.gc p{margin:0;color:#d6d4cd}' +
    '.gc a{color:#f3f1ea;text-decoration:underline;text-underline-offset:3px;text-decoration-color:#ff3b1d}' +
    '.gc-actions{display:flex;flex-wrap:wrap;gap:10px;margin-top:16px}' +
    '.gc button{flex:1 1 9rem;min-height:44px;padding:0 18px;border-radius:9999px;font:inherit;font-size:13px;font-weight:600;text-transform:uppercase;letter-spacing:0.14em;cursor:pointer;transition:background-color 200ms ease-out,border-color 200ms ease-out}' +
    '.gc .gc-yes{background:#ff3b1d;color:#08080a;border:1px solid #ff3b1d}' +
    '.gc .gc-yes:hover{background:#ff6a3d;border-color:#ff6a3d}' +
    '.gc .gc-no{background:transparent;color:#f3f1ea;border:1px solid rgba(243,241,234,0.32)}' +
    '.gc .gc-no:hover{border-color:#f3f1ea}' +
    '.gc button:focus-visible{outline:2px solid #ff3b1d;outline-offset:3px}' +
    '@media (prefers-reduced-motion:reduce){.gc{transition:none}}' +
    '@media (min-width:768px){.gc{right:auto}}' +
    'body:has(#wixheadless-banner-container) .gc{bottom:calc(76px + env(safe-area-inset-bottom,0px))}';

  var box = null;
  function build() {
    if (box) return box;
    var st = document.createElement('style');
    st.textContent = css;
    document.head.appendChild(st);
    box = document.createElement('section');
    box.className = 'gc';
    box.setAttribute('aria-label', 'Cookie choices');
    box.setAttribute('aria-live', 'polite');
    box.innerHTML =
      '<h2>Your privacy</h2>' +
      '<p>We use essential storage to run bookings, and analytics to see how the site is used. You choose whether analytics runs. Read our <a href="/privacy.html#cookies">Privacy Policy</a>.</p>' +
      '<div class="gc-actions"><button type="button" class="gc-yes">Accept all</button><button type="button" class="gc-no">Essential only</button></div>';
    box.querySelector('.gc-yes').addEventListener('click', function () { choose('all'); });
    box.querySelector('.gc-no').addEventListener('click', function () { choose('essential'); });
    document.body.appendChild(box);
    return box;
  }
  function show(focus) {
    var b = build();
    b.hidden = false;
    requestAnimationFrame(function () { requestAnimationFrame(function () { b.classList.add('on'); }); });
    if (focus) setTimeout(function () { b.querySelector('.gc-yes').focus(); }, 60);
  }
  function hide() {
    if (!box) return;
    box.classList.remove('on');
    setTimeout(function () { if (box && !box.classList.contains('on')) box.hidden = true; }, 450);
  }
  function choose(choice) {
    write(choice);
    applyToWix(choice);
    hide();
  }

  window.gleamConsent = { open: function () { show(true); }, get: function () { var v = read(); return v ? v.choice : null; } };

  document.addEventListener('click', function (e) {
    var t = e.target.closest && e.target.closest('[data-cookie-settings]');
    if (t) { e.preventDefault(); show(true); }
  });

  function start() {
    var saved = read();
    if (saved) { applyToWix(saved.choice); return; }
    // Honor the browser's Global Privacy Control signal as an opt-out, without asking.
    if (navigator.globalPrivacyControl === true) { write('essential'); applyToWix('essential'); return; }
    setTimeout(function () { show(false); }, 1800);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();
})();

/* Gleam: light / dark switch. Dark is the default; a visitor's choice is remembered on their device. */
(function () {
  var KEY = 'gleam-theme';
  var root = document.documentElement;
  function current() { return root.getAttribute('data-theme') === 'light' ? 'light' : 'dark'; }
  function sync() {
    var light = current() === 'light';
    var meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', light ? '#ffffff' : '#08080a');
    var btns = document.querySelectorAll('[data-theme-toggle]');
    for (var i = 0; i < btns.length; i++) {
      btns[i].setAttribute('aria-pressed', light ? 'true' : 'false');
      btns[i].setAttribute('aria-label', light ? 'Switch to dark mode' : 'Switch to light mode');
      btns[i].setAttribute('title', light ? 'Dark mode' : 'Light mode');
    }
  }
  function set(theme) {
    root.classList.add('theme-anim');
    if (theme === 'light') root.setAttribute('data-theme', 'light'); else root.removeAttribute('data-theme');
    try { localStorage.setItem(KEY, theme); } catch (e) {}
    sync();
    clearTimeout(set._t);
    set._t = setTimeout(function () { root.classList.remove('theme-anim'); }, 500);
  }
  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('[data-theme-toggle]');
    if (!b) return;
    e.preventDefault();
    set(current() === 'light' ? 'dark' : 'light');
  });
  window.gleamTheme = { set: set, get: current };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', sync); else sync();
})();